from class_truss import truss

if __name__ == "__main__":

    # トラスの形状ファイル
    file = "truss07.txt"
    
    # トラスオブジェクト(tr)を生成
    tr = truss(file)

    # マトリクス構造解析
    truss.analysis(tr)

    # 結果を表示
    truss.plot(tr)
