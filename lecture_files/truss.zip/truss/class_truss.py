import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as pat

class truss:

    # コンストラクタ
    def __init__(self,filename):

        # 節点数nvを読み込み
        line = 1 #行番号をinitialise
        self.nv = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=1, dtype=int)
        print("Number of nodes =", self.nv)

        # 節点の座標xを読み込み
        # x[i,0] = i番節点のx座標
        # x[i,1] = i番節点のy座標
        line += 1 #行番号をincrement
        self.x = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=self.nv, usecols=(1,2))
        print("Nodes =", self.x)
        
        # 節点の境界条件タイプを読み込み
        # ibc[i] = i番節点が 0: フリー, 1: x軸方向固定, 2: y軸方向固定, 3: 固定
        self.ibc = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=self.nv, usecols=(3), dtype=int)
        print("Boundary conditions =", self.ibc)

        # 荷重を読み込み
        # f[j,i] = j番節点に作用するx_i方向の荷重
        self.f = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=self.nv, usecols=(4,5))
        print("Loads =", self.f)
        
        # 要素(=トラス部材)の数(ne)を読み込み
        line += self.nv #行番号をincrement
        self.ne = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=1, dtype=int)
        print("Number of elements =", self.ne)
        
        # 要素の繋がり方(nd)を読み込み
        # nd[i,0] = i番要素の「始点」の節点番号
        # nd[i,1] = i番要素の「終点」の節点番号
        line += 2 #行番号をincrement
        self.nd = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=self.ne, usecols=(1,2), dtype=int)
        print("Nodes =", self.nd)

        # 要素の断面積(area)を読み込み
        # area[i] = i番要素の断面積
        self.area = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=self.ne, usecols=(3))
        print("Area =", self.area)

        # 要素のヤング率(E)を読み込み
        # area[i] = i番要素の断面積
        self.E = np.genfromtxt(filename, comments="#", skip_header=line, max_rows=self.ne, usecols=(4))
        print("Young's modulus =", self.E)
        
        # 要素の長さを計算
        # lngth[i] = i番要素の長さ
        self.lngth=np.array(np.sqrt(
             (self.x[self.nd[:,1],0]-self.x[self.nd[:,0],0])**2
            +(self.x[self.nd[:,1],1]-self.x[self.nd[:,0],1])**2
        ))
        print("Length=", self.lngth)
        
        # 法線ベクトルの長さを計算
        # nvec[i,j] = j番要素の「法線」ベクトルの x_i 成分
        self.nvec = np.array([[(self.x[self.nd[j,1],i]-self.x[self.nd[j,0],i])/self.lngth[j]
                               for i in range(2)] for j in range(self.ne)])
        print("Normal vector=", self.nvec)

    def analysis(self):

        local_mat = np.zeros((4,4))
        global_mat = np.zeros((2*self.nv,2*self.nv))        

        for i in range(self.ne):
            eal = self.E[i]*self.area[i]/self.lngth[i]
            n0 = self.nvec[i,0]
            n1 = self.nvec[i,1]

            # 要素剛性行列を計算し、
            local_mat[0][0]=eal*n0*n0
            local_mat[1][0]=eal*n1*n0
            local_mat[0][1]=eal*n0*n1
            local_mat[1][1]=eal*n1*n1

            local_mat[0][2]=-eal*n0*n0
            local_mat[1][2]=-eal*n1*n0
            local_mat[0][3]=-eal*n0*n1
            local_mat[1][3]=-eal*n1*n1

            local_mat[2][0]=-eal*n0*n0
            local_mat[3][0]=-eal*n1*n0
            local_mat[2][1]=-eal*n0*n1
            local_mat[3][1]=-eal*n1*n1

            local_mat[2][2]=eal*n0*n0
            local_mat[3][2]=eal*n1*n0
            local_mat[2][3]=eal*n0*n1
            local_mat[3][3]=eal*n1*n1

            for j in range(2):
                for k in range(2):
                    # 全体剛性行列に放り込む
                    global_mat[2*self.nd[i,j]  ][2*self.nd[i,k]  ] += local_mat[2*j  ][2*k  ]
                    global_mat[2*self.nd[i,j]+1][2*self.nd[i,k]  ] += local_mat[2*j+1][2*k  ]
                    global_mat[2*self.nd[i,j]  ][2*self.nd[i,k]+1] += local_mat[2*j  ][2*k+1]
                    global_mat[2*self.nd[i,j]+1][2*self.nd[i,k]+1] += local_mat[2*j+1][2*k+1]

        # Dirichlet境界条件の処理
        large_num = 100000.0
        for i in range(self.nv):
            if(self.ibc[i] == 1):
                global_mat[2*i  ][2*i  ] += large_num
            elif(self.ibc[i] == 2):
                global_mat[2*i+1][2*i+1] += large_num
            elif(self.ibc[i] == 3):
                global_mat[2*i  ][2*i  ] += large_num
                global_mat[2*i+1][2*i+1] += large_num

        # 荷重ベクトルを右辺ベクトルに reshape
        b = self.f.reshape(self.nv*2)
        self.u = np.linalg.solve(global_mat, b)

    # 断面積を反映したトラスの絵を描く 
    def plot_with_area(self):
        # fix, ax の生成
        fig = plt.figure(1)
        ax = fig.add_subplot(111)

        # 縦横比を実寸に
        ax.set_aspect("equal")

        # 変形前の節点をplot
        for i in range(self.nv):
            ax.scatter(self.x[i,0],self.x[i,1], marker="o", color="black", lw=10, zorder=2)
        
        # 部材を長方形として ax に追加していく
        scale = 0.05 #太すぎるので適当にスケーリング

        for i in range(self.ne):
            x0 = (self.x[self.nd[i,0],0]-0.5*self.area[i]*self.nvec[i,1]*scale,
                  self.x[self.nd[i,0],1]+0.5*self.area[i]*self.nvec[i,0]*scale) #左下
            x1 = (x0[0]+self.lngth[i]*self.nvec[i,0],
                  x0[1]+self.lngth[i]*self.nvec[i,1]) #右下
            x2 = (x1[0]+self.area[i]*self.nvec[i,1]*scale,
                  x1[1]-self.area[i]*self.nvec[i,0]*scale) #右上
            x3 = (x2[0]-self.lngth[i]*self.nvec[i,0],
                  x2[1]-self.lngth[i]*self.nvec[i,1]) #右下
            p = pat.Polygon(xy = [x0, x1, x2, x3], fc = "gray", zorder=1)
            ax.add_patch(p)

            
        ax.set_xlim(np.amin(self.x[:,0])-1,np.amax(self.x[:,0])+1)
        ax.set_ylim(np.amin(self.x[:,1])-1,np.amax(self.x[:,1])+1)
        plt.show()
            
    # 変形前後のトラスのplot
    def plot(self):

        # fix, ax の生成
        fig = plt.figure(1)
        ax = fig.add_subplot(111)

        # 縦横比を実寸に
        ax.set_aspect("equal")

        # 変形前の要素をplot
        for i in range(self.ne):
            ax.plot(self.x[self.nd[i,:],0],self.x[self.nd[i,:],1], color="black", lw=0.5)

        # 変形前の節点をplot
        for i in range(self.nv):
            if(self.ibc[i] == 0):
                ax.scatter(self.x[i,0],self.x[i,1], marker="o", color="black")
            elif(self.ibc[i] == 1):
                ax.scatter(self.x[i,0],self.x[i,1], marker="^", color="black")
            elif(self.ibc[i] == 2):
                ax.scatter(self.x[i,0],self.x[i,1], marker="v", color="black")
            else:
                ax.scatter(self.x[i,0],self.x[i,1], marker="*", color="black")
                
        # 変形後の要素をplot
        for i in range(self.ne):
            ax.plot(self.x[self.nd[i,:],0]+self.u[2*self.nd[i,:]],
                    self.x[self.nd[i,:],1]+self.u[2*self.nd[i,:]+1], color="blue", lw=2.0, label="aaa")

        # 変形後の節点をplot
        for i in range(self.nv):
            if(self.ibc[i] == 0):
                ax.scatter(self.x[i,0]+self.u[2*i],self.x[i,1]+self.u[2*i+1], marker="o", color="blue")
            elif(self.ibc[i] == 1):
                ax.scatter(self.x[i,0]+self.u[2*i],self.x[i,1]+self.u[2*i+1], marker="^", color="blue")
            elif(self.ibc[i] == 2):
                ax.scatter(self.x[i,0]+self.u[2*i],self.x[i,1]+self.u[2*i+1], marker="v", color="blue")
            else:
                ax.scatter(self.x[i,0]+self.u[2*i],self.x[i,1]+self.u[2*i+1], marker="*", color="blue")

        # 軸
        ax.set_xlabel("x")
        ax.set_ylabel("y")
                
        # 凡例        
        ax.text(np.amax(self.x[:,0])-1.8,np.amin(self.x[:,1])+0.35,"Before deformation",color="black")
        ax.text(np.amax(self.x[:,0])-1.8,np.amin(self.x[:,1])+0.15,"After deformation",color="blue")

        # 表示
        plt.show()
